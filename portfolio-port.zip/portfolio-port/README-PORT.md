# Player Portfolio — port bundle (from Replit Task #123 → current main)

Built 2026-09-24 from the #123 snapshot commit `5205468` (branch `claim-player-bunny-overlay`).
Verified fact behind this bundle: the #123 tree already contains main's Sep 21–23 work (match rooms,
three-team matches, pay-at-field, avatar system — byte-identical to main). The portfolio feature is the
ONLY thing #123 has that main lacks. It touches **16 files: 4 new, 12 modified.** Everything below is
"move as-is": no redesign, no additions, no fixes to the sharing flow yet.

Read this whole file before touching anything. Every edit is listed; if something here does not match
what main actually contains, STOP and report the difference instead of improvising.

---

## 0. Ground rules for the port

- The DB is already live: `users.nation`, `users.profile_photo`, `user_clips.show_in_portfolio`,
  table `portfolio_history` exist in the shared database. **Do not run `drizzle-kit push`, `push-force`,
  migrations, or any SQL write.** The schema edits in §1 only DECLARE what is already there.
- Spec-first: after editing `lib/api-spec/openapi.yaml`, run
  `pnpm --filter @workspace/api-spec run codegen` BEFORE touching TS that imports the generated hooks/types.
  Generated output is git-tracked — commit it.
- No query parameters in the spec (Orval type-collision gotcha) — the fragments here have none.
- Keep every other file exactly as main has it. The raw hunks in `reference/` come from #123's diff against
  an OLD base and contain lots of main-side changes that are already on main — never apply them blindly.

---

## 1. Database schema declarations (declare-to-preserve; no push)

### 1a. NEW `lib/db/src/schema/portfolio.ts`
Copy verbatim from `new/lib/db/src/schema/portfolio.ts`.

### 1b. `lib/db/src/schema/users.ts` — add two columns
Main currently has:
```ts
  position: text("position"),
  age: integer("age"),
  gender: text("gender"),
  isDisabled: boolean("is_disabled").notNull().default(false),
```
Make it:
```ts
  position: text("position"),
  age: integer("age"),
  gender: text("gender"),
  nation: text("nation"),
  profilePhoto: text("profile_photo"),
  isDisabled: boolean("is_disabled").notNull().default(false),
```
Nothing else in the file changes (main already has `plan`, consent columns, `avatarPath`, `shirtNumber`).

### 1c. `lib/db/src/schema/userClips.ts` — add one column
Main currently has:
```ts
  visibility: text("visibility").notNull().default("private"),
  thumbnailTime: numeric("thumbnail_time", { precision: 10, scale: 3 }),
```
Make it:
```ts
  visibility: text("visibility").notNull().default("private"),
  showInPortfolio: boolean("show_in_portfolio").notNull().default(false),
  thumbnailTime: numeric("thumbnail_time", { precision: 10, scale: 3 }),
```
`boolean` is already imported in that file.

### 1d. `lib/db/src/schema/index.ts` — add one export
After `export * from "./userClips";` add:
```ts
export * from "./portfolio";
```

---

## 2. API server

### 2a. NEW `artifacts/api-server/src/routes/portfolios.ts`
Copy verbatim from `new/artifacts/api-server/src/routes/portfolios.ts`.
Its imports all resolve on main: `followsTable`/`portfolioHistoryTable`/`userClipsTable`/`usersTable` from
`@workspace/db`; `getLocalAccountUserId`/`unauthenticatedResponse` from `../lib/clerkUserBridge`;
`getBunnyProxiedPlaybackUrl`/`getBunnyProxiedThumbnailUrl`/`isBunnyConfigured` from `../lib/bunny`;
`isLiveVideoId` from `./userClips`. The `@workspace/api-zod` names (`GetUserPortfolioParams`,
`GetUserPortfolioResponse`, `UpdateUserPortfolioBody`, `UpdateUserPortfolioParams`,
`UpdateUserPortfolioResponse`) come from codegen (§4).

### 2b. `artifacts/api-server/src/routes/index.ts` — mount it
Add the import (after `import matchRoomsRouter from "./matchRooms";`):
```ts
import portfoliosRouter from "./portfolios";
```
Add the mount **directly after** `router.use(usersRouter);`:
```ts
router.use(portfoliosRouter);
```
(Order matters: it must be mounted after `usersRouter`, as in #123.)

### 2c. `artifacts/api-server/src/routes/userClips.ts` — three hunks
Apply `patches/userClips.route.portfolio.patch`. Line numbers are stale; apply by context
(`git apply --3way --recount` or `patch -p1 --fuzz=3`), or by hand:
1. In `POST /user-clips` response object: add `showInPortfolio: row.showInPortfolio,` after `visibility: row.visibility,`.
2. In `PATCH /user-clips/:id`: extend the `updates` type with `showInPortfolio: boolean` and add the
   share/unshare invariant block (share ⇒ `visibility = "public"`; non-public visibility change ⇒ `showInPortfolio = false`).
3. In `PATCH /user-clips/:id` response object: add `showInPortfolio: row.showInPortfolio,` after `visibility: row.visibility,`.

---

## 3. Frontend

### 3a. NEW `artifacts/soccerwatch/src/features/portfolio/model.ts` and `page.tsx`
Copy both verbatim from `new/artifacts/soccerwatch/src/features/portfolio/`. Create the `features/portfolio/`
directory (main has no `features/` dir yet). `page.tsx` default-exports `PortfolioPage`. Imports resolve on
main: `@/lib/utils`, `@/i18n`, `lucide-react`, `framer-motion`, `@tanstack/react-query`, `wouter`, and the
generated `useGetUserPortfolio` / `useUpdateUserPortfolio` / `getGetUserPortfolioQueryKey` /
`useUpdateUserClip` / `PortfolioClip` / `PortfolioView` from `@workspace/api-client-react` (codegen, §4).

### 3b. `artifacts/soccerwatch/src/App.tsx` — route + Toaster guard
Main imports pages statically and has NO lazy loading — keep it that way (the #123 lazy-route performance
pass is deliberately NOT part of this move).
1. Add, with the other page imports:
   ```tsx
   import PortfolioPage from "@/features/portfolio/page";
   ```
2. In `AppRouter`'s `<Switch>`, directly after `<Route path="/players/:id" component={Profile} />` add:
   ```tsx
   <Route path="/portfolio/:id" component={PortfolioPage} />
   ```
3. In `ClerkProviderWithRoutes`: change `const [, setLocation] = useLocation();` to
   `const [location, setLocation] = useLocation();` and change `<Toaster />` to
   ```tsx
   {!location.startsWith("/portfolio/") && <Toaster />}
   ```
`AuthRedirectGuard` is NOT changed — #123's copy is identical to main's (no portfolio exemption). That is
the as-is behaviour; do not add one.

### 3c. `artifacts/soccerwatch/src/components/layout.tsx` — hide header + tab bar on the portfolio
Main currently has:
```tsx
  const isImmersivePlayer = location.startsWith("/player/") || location.startsWith("/claim/");
  const isWatchFeed = location === "/home";
```
Insert between them:
```tsx
  const isPortfolio = location.startsWith("/portfolio/");
```
and change
```tsx
  const hideTabBar = isLogin || isImmersivePlayer || isAuthPage || isFullscreenVideo || isOwnerShare || isOwnerVar || isMatchRoom;
```
to
```tsx
  const hideTabBar = isLogin || isImmersivePlayer || isPortfolio || isAuthPage || isFullscreenVideo || isOwnerShare || isOwnerVar || isMatchRoom;
```
Nothing else in layout.tsx changes.

### 3d. `artifacts/soccerwatch/src/pages/account.tsx` — "My Portfolio" row
1. Add `Sparkles` to the existing lucide import:
   `import { ChevronRight, ChevronLeft, LogOut, Globe, Pencil, Shield, Video } from "lucide-react";`
   → `import { ChevronRight, ChevronLeft, LogOut, Globe, Pencil, Shield, Video, Sparkles } from "lucide-react";`
2. In the Settings list, the block `{!isGuest && user && ( <button onClick={() => setIsEditOpen(true)} …Edit Profile… </button> )}`
   becomes a fragment with the portfolio link FIRST, then the unchanged Edit Profile button:
   ```tsx
   {!isGuest && user && (
     <>
       <Link
         href={`/portfolio/${user.id}`}
         className="flex w-full items-center justify-between bg-card p-4 transition-colors hover:bg-muted/30"
       >
         <div className="flex items-center gap-3">
           <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-muted/50">
             <Sparkles className="h-4 w-4 text-primary" />
           </span>
           <span className="font-medium text-foreground">{t.account.myPortfolio}</span>
         </div>
         <ChevronRight className="h-5 w-5 text-muted-foreground rtl:hidden" />
         <ChevronLeft className="h-5 w-5 text-muted-foreground ltr:hidden" />
       </Link>
       <button onClick={() => setIsEditOpen(true)} … (existing Edit Profile button, unchanged) … </button>
     </>
   )}
   ```
   Row order on the page is then: My Portfolio → Edit Profile → Language → Owner Console (conditional) → Admin (conditional).

### 3e. `artifacts/soccerwatch/src/pages/my-clips.tsx` — portfolio toggle, badge, consent dialog
Apply `patches/my-clips.tsx.portfolio.patch` (four hunks, all inside `UserClipCard`); line numbers are stale,
apply by context or by hand. Then fix imports so it typechecks:
- `Eye` from `lucide-react` (add to the existing lucide import line).
- `useUpdateUserClip` from `@workspace/api-client-react` (add to the existing import block; it is the
  generated hook for `PATCH /user-clips/{id}`).
- `useEffect` from `react`, `useTranslation` from `@/i18n`, `cn` from `@/lib/utils` — main's file very likely
  imports these already; add only what is missing.
Note: #123's own diff never shows a `useUpdateUserClip` import line for this file — treat that as a thing to
verify with typecheck, not as a decision.

### 3f. `artifacts/soccerwatch/src/i18n/strings.ts` — six blocks
Add the blocks in `fragments/strings.ts.additions.txt`: `myClips.*` portfolio keys (EN+AR),
`account.myPortfolio` (EN+AR), and a new top-level `portfolio: { … }` section (EN+AR) placed after
`academies`. Keys must be identical in EN and AR (the file is `as const`, so a missing key on one side is
a type error — that is the check).

### 3g. `artifacts/soccerwatch/src/index.css` — append the portfolio stylesheet
Append `fragments/index.css.append.css` (228 lines, starts with the "Player portfolio story" banner
comment) to the END of `index.css`. In #123 it is the last block of the file. Nothing else in index.css changes.

---

## 4. OpenAPI spec + codegen

`lib/api-spec/openapi.yaml`:
1. **Paths** — insert `fragments/openapi.paths.portfolio.yaml` under `paths:` right after the `/users/{id}:` entry.
   The fragment shows `get:` and `patch:` under two repeated `/users/{id}/portfolio:` keys (extractor artefact);
   in the real file they go under ONE `/users/{id}/portfolio:` key.
2. **Schemas** — insert `fragments/openapi.schemas.portfolio.yaml` under `components.schemas:`
   (PortfolioHistoryItem, PortfolioClip, PortfolioView, UpdatePortfolioHistoryItem, UpdatePortfolioInput).
3. **Property additions to existing schemas** (add only these lines; do not replace the schemas):
   - `User` (the /me object): after `gender:` add
     ```yaml
        nation:
          type: ["string", "null"]
        profilePhoto:
          type: ["string", "null"]
     ```
   - `UserClip`: add `showInPortfolio` to the `required` list (after `visibility`) and the property
     ```yaml
        showInPortfolio:
          type: boolean
     ```
     after `visibility`.
   - `UpdateUserClipInput`: add the optional property
     ```yaml
        showInPortfolio:
          type: boolean
     ```
   `reference/openapi.User+UserClip+UpdateUserClipInput.as-in-123.yaml` shows how those three schemas read in
   #123 for comparison after editing — do not paste it over main's versions.
4. Run `pnpm --filter @workspace/api-spec run codegen`. Expect new `useGetUserPortfolio`, `useUpdateUserPortfolio`,
   `getGetUserPortfolioQueryKey`, `PortfolioView`, `PortfolioClip` … in `@workspace/api-client-react`, and
   `GetUserPortfolio*` / `UpdateUserPortfolio*` in `@workspace/api-zod`.

---

## 5. Not in this move (on purpose)

- The #123 lazy-route / Suspense / lazy-Clerk-arSA performance pass in App.tsx.
- `/claim-match/` and `location === "/owner"` additions to layout.tsx's chrome rules.
- The `.agents/memory/*` notes, screenshots, attached_assets, migrations 0018–0030, `typecheck-fixes.patch`.
- Any fix to the clip-sharing flow. Known observation for the NEXT phase, not for this one: #123 only added
  `showInPortfolio` to the `POST /user-clips` and `PATCH /user-clips/:id` responses; the list endpoint that
  feeds My Clips may not return it, which would leave the badge/toggle stateless. Report what you find; do
  not fix it during the move.

## Bundle contents
```
README-PORT.md
new/lib/db/src/schema/portfolio.ts
new/artifacts/api-server/src/routes/portfolios.ts
new/artifacts/soccerwatch/src/features/portfolio/model.ts
new/artifacts/soccerwatch/src/features/portfolio/page.tsx
fragments/index.css.append.css
fragments/openapi.paths.portfolio.yaml
fragments/openapi.schemas.portfolio.yaml
fragments/strings.ts.additions.txt
patches/userClips.route.portfolio.patch
patches/my-clips.tsx.portfolio.patch
reference/openapi.User+UserClip+UpdateUserClipInput.as-in-123.yaml
reference/123-raw-hunks__*.patch   (stale-context originals — read, never apply)
```
